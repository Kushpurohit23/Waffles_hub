from django.db import models

# Create your models here.
class product(models.Model):
    stock = models.IntegerField(default=10)
    pname = models.CharField(max_length=122,default="wf1")
    
    def __str__(self):
        return self.pname
    
