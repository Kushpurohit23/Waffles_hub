
from django.contrib import admin
from django.urls import path
from home import views

urlpatterns = [
    path('',views.id,name='home'),
    path('home',views.id,name='home'),
    path('login',views.log_in,name='login'),
    path('logout',views.log_out,name='logout'),
    path('signup',views.sign_up,name='logout'),
    path('check1',views.check1,name='check1'),
    path('check2',views.check2,name='check2'),
    path('check3',views.check3,name='check3'),
    path('sell',views.sell,name='sell')
]
