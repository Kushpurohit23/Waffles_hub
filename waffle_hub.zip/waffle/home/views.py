from django.shortcuts import render,HttpResponse,redirect
from django.contrib.auth import authenticate,login,logout
from home.models import product
# from frost.models import User
from django.contrib.auth.models import User

# Create your views here.
def id(request) :
    return render(request,'home.html')

def log_in(request) :
    if request.method=="POST" :
        u=request.POST.get('uname')
        pw=request.POST.get('pass')
        user = authenticate(username=u,password=pw)
        print(u,pw)
        if user is not None :
            login(request,user)
            return redirect("/home")
    return render(request,'login.html')
def log_out(request) :
    if request.user.is_authenticated :
        logout(request)
        return render(request,"logout.html")
    return redirect("/login")
def sign_up(request):
    if request.method=="POST":
        un = request.POST.get('username')
        p = request.POST.get('pass')
        pc = request.POST.get('cpass')
        if(un != None and p !=None and p==pc) :
            
            user = User.objects.create_user(username=un,password=p)
            if(user is not None):
                user.save()
                return redirect('/login')
    return render(request,'register.html')

def check1(request):
    s=-1
    for j in product.objects.all():
        if j.pname == "wf1": s=j.stock
    print(s)
    if(request.user.is_authenticated):
      
        return render(request,"buy.html",{"pname":"wf1"})
    else:
        return redirect("/login")
    
def check2(request):
    s=-1
    for j in product.objects.all():
        if j.pname == "wf2": s=j.stock
    print(s)
    if(request.user.is_authenticated):
       
    
        return render(request,"buy.html",{"pname":"wf2"})
    else:
        return redirect("/login")

def check3(request):
    s=-1
    for j in product.objects.all():
        if j.pname == "wf3": s=j.stock
    print(s)
    if(request.user.is_authenticated):
       
       
        return render(request,"buy.html",{"pname":"wf3"})
    else:
        return redirect("/login")
def sell(request):
    print("hii")
    if(request.user.is_authenticated and request.method=="POST"):
        q=int(request.POST.get('qty'))
        print(q)
        p = request.POST.get('pro')
        ins = product.objects.filter(pname=p)[0]
        if(ins.stock < q) :
            return render(request,'error.html')
        ins.stock = ins.stock - q
        ins.save()
        return redirect('/home')
    return HttpResponse("can't update")